from enum import Enum


class SUIT(Enum):
    HEART, SPADE, CLUB, DIAMOND = 1, 2, 3, 4

